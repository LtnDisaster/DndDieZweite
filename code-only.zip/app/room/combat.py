"""Combat: initiative tracking and DM HP adjustments."""
import json
import random

from .. import db, npc
from .. import conditions as C
from . import death as D, health
from .dice import dex_mod
from .net import broadcast, sys_msg


def step_conditions(room_id):
    """Advance timed conditions on every token by one round.

    Returns a list of ``(token_id, new_conds)`` for the tokens that changed, so the
    caller can stream the updates. Permanent (``rounds == 0``) conditions are kept.
    """
    changed = []
    for tok in db.q("SELECT id, conds FROM tokens WHERE room_id=?", (room_id,)):
        new, dirty = C.step_rounds(C.load(tok))
        if dirty:
            db.x("UPDATE tokens SET conds=? WHERE id=?", (db.json_dumps(new), tok["id"]))
            changed.append((tok["id"], new))
    return changed


def token_dex_mod(tok):
    """DEX modifier for any token: an attached character, else an NPC stat block."""
    if tok["character_id"]:
        return dex_mod(tok["character_id"])
    block = npc.load(tok)
    return npc.dex_mod(block) if block else 0


def get_init(room_id):
    st = db.q1("SELECT initiative FROM room_state WHERE room_id=?", (room_id,))
    init = db.j((st or {}).get("initiative"), {"combat": False, "order": [], "active": -1, "round": 0}) \
        or {"combat": False, "order": [], "active": -1, "round": 0}
    if "round" not in init:                     # pre-round saves default sensibly
        init["round"] = 1 if init.get("combat") else 0
    return init


def set_init(room_id, init):
    db.x("UPDATE room_state SET initiative=? WHERE room_id=?", (json.dumps(init), room_id))


async def handle_init_start(ws, room_id, user, is_dm, msg):
    if not is_dm:
        return
    order = []
    for tok in db.q("SELECT * FROM tokens WHERE room_id=? ORDER BY id", (room_id,)):
        mod = token_dex_mod(tok)
        roll = random.randint(1, 20)
        order.append({"token_id": tok["id"], "label": tok["label"], "color": tok["color"],
                      "mod": mod, "roll": roll, "total": roll + mod})
    order.sort(key=lambda o: o["total"], reverse=True)
    init = {"combat": True, "round": 1, "order": order, "active": 0}
    set_init(room_id, init)
    sys_msg(room_id, "Combat started! — Round 1")
    await broadcast(room_id, "initiative", init)


async def handle_init_next(ws, room_id, user, is_dm, msg):
    if not is_dm:
        return
    init = get_init(room_id)
    if init["combat"] and init["order"]:
        init["active"] = (init["active"] + 1) % len(init["order"])
        set_init(room_id, init)
        await broadcast(room_id, "initiative", init)


async def handle_init_end_round(ws, room_id, user, is_dm, msg):
    """DM ends the current round: increment the round counter and return to the
    top of the (still fixed) initiative order. Initiative is rolled once per
    combat (D22), not re-rolled here."""
    if not is_dm:
        return
    init = get_init(room_id)
    if not init["combat"] or not init["order"]:
        return
    init["round"] = int(init.get("round", 1)) + 1
    init["active"] = 0
    set_init(room_id, init)
    for token_id, conds in step_conditions(room_id):
        await broadcast(room_id, "cond", {"token_id": token_id, "conds": conds})
    sys_msg(room_id, f"— Round {init['round']} —")
    await broadcast(room_id, "initiative", init)


async def handle_init_end(ws, room_id, user, is_dm, msg):
    if not is_dm:
        return
    init = {"combat": False, "order": [], "active": -1, "round": 0}
    set_init(room_id, init)
    sys_msg(room_id, "Combat ended.")
    await broadcast(room_id, "initiative", init)


async def handle_hp(ws, room_id, user, is_dm, msg):
    if not is_dm:
        return
    tok = db.q1("SELECT * FROM tokens WHERE id=? AND room_id=?", (msg.get("token_id", -1), room_id))
    if tok is None:
        return
    try:
        delta = max(-9999, min(9999, int(msg.get("delta", 0))))
    except (TypeError, ValueError):
        return
    dtype = str(msg.get("damage_type", "")).strip().lower() or None
    res = await health.change_hp(room_id, tok, delta, crit=bool(msg.get("crit")),
                                 damage_type=dtype, broadcast_change=False)
    if res is None:
        return
    if delta < 0 and res.get("immune"):
        sys_msg(room_id, f"{res['name']} takes no {dtype or 'damage'} damage.")
        await broadcast(room_id, "snapshot", None)
        return
    if not res.get("changed"):
        return
    if delta < 0:
        verb, amount = "takes", res["damage"]
    else:
        verb, amount = "heals", res["healed"]
    sys_msg(room_id, f"{res['name']} {verb} {amount} → {res['hp']}/{res['max_hp']} HP{res.get('note', '')}")
    await broadcast(room_id, "snapshot", None)
