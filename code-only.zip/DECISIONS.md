# Architecture Decision Records — D&D VTT (`/home/alp/Test`)

Purpose: capture the decisions taken while building this app so later instances
(human or AI) can recover the *why* without re-deriving it from code.
Each record: Context → Decision → Alternatives → Consequences → Status.

Last touched: 2026-10-02 (multi-cell footprints, wall/door LOS, manual fog, movement stop,
server path preview).
Current test status: `pytest` **162 passed** (unit + in-repo integration). Dev-only live
WS smoke suites (still in `/tmp/opencode/`) re-run green after these changes.

## D1 — Tech stack: FastAPI + WebSockets + SQLite + vanilla JS
- **Context:** Self-hosted multiplayer VTT, must run anywhere with one command, no build toolchain.
- **Decision:** FastAPI + `uvicorn`, stdlib `sqlite3` (WAL), browser WebSocket, canvas SPA with no bundler/framework.
- **Alternatives:** Node/Socket.IO, React+Vite, Postgres.
- **Consequences:** Zero build step (`./run.sh`); single Python process; frontend is split into classic (non-module) `<script>` files under `app/static/js/` loaded in dependency order (shared global scope, no bundler).
- **Status:** Accepted.

## D2 — Auth: bcrypt + HMAC-signed 30-day cookie
- **Context:** Local single-tenant install; want stateless sessions, no DB session table.
- **Decision:** `auth.py` hashes passwords with bcrypt, signs an `HttpOnly` `vtt_session` cookie with a key in `data/secret.key`.
- **Status:** Accepted.

## D3 — Everything authoritative is server-side
- **Context:** VTT cheating is trivial if clients compute results.
- **Decision:** Dice, A* pathfinding, HP deltas, trap/loot resolution, item math (AC/heal/charges/attunement) are computed in `app/room/*` and `gear.py`, never trusted from the browser.
- **Consequences:** Slightly chattier protocol; clients are dumb renderers. This is the load-bearing security decision.
- **Status:** Accepted.

## D4 — Grid + fog model, per-role map filtering
- **Context:** Need hidden traps/loot and fog-of-war that never leak secret data to players.
- **Decision:** `mapmodel.py` holds `cells` (0 floor/1 wall/2 difficult), `traps`, `loot`, an `explored` bitmap, radius-6 reveal streamed as *terrain patches* (`explored` events carry `{cells, terrain}`). `visible_map(mp, uid, is_dm, owned)` filters per recipient.
- **Consequences:** Unexplored terrain/traps/loot are never serialized to a player; fog lifts live during a walk.
- **Status:** Accepted.

## D5 — A* pathfinding: 8-dir, no corner-cutting, difficult terrain ×2, `max_steps=400`
- **Context:** Server must move tokens along legal, believable paths.
- **Decision:** `path.py::find_path` (octile costs 10/14, walls block, difficult terrain doubles step cost, no diagonal corner cutting, 400-step cap).
- **Consequences:** The **client preview must mirror this exactly** (D7). Two implementations of one algorithm = drift risk (see TODO).
- **Status:** Accepted.

## D6 — Movement protocol: per-step events + DM teleport
- **Context:** Animate server walks; DM needs instant reposition.
- **Decision:** `{type:"move", token_id, tx, ty, teleport?}`; server walks emitting `step {token_id,x,y,cx,cy}`; `teleport` honored only for DM.
- **Status:** Accepted.

## D7 — Two-click confirm movement (players)
- **Context:** Users asked for a *visible, changeable* route before committing; drag-and-drop commits too eagerly and mis-moves.
- **Decision:** First empty-cell click **plans** (gold route preview via a JS A* mirror `findPathJS` in `js/50_canvas.js`); second click on the same cell (or the floating `#movehud` **Move** button) commits; other cell re-plans; `Esc`/Cancel aborts. Player **drag** sets a plan instead of auto-moving. DM keeps drag = teleport.
- **Alternatives:** Drag-to-commit (rejected: too easy to mis-drop), hover-preview-only (rejected: no explicit confirm).
- **Consequences:** Player and DM movement diverge; preview is advisory — server re-runs authoritative A* and may still reply "No path there".
- **Status:** Accepted.

## D8 — Strict line-of-sight, targeted token events, last-seen ghosts
- **Context:** Requirement: out-of-sight movement of *anyone* (incl. allies) must not leak; sight should fade to a "memory".
- **Decision:** Vision radius `VISION_R = 6` (Chebyshev). Replaced global broadcasts with `app/room/visibility.py::send_token_event`, which per viewer decides: first sight → `token_add`, subsequent → `step`, losing sight → `token_leave`, deletion → `token_gone`. Server keeps `_last_seen[room][viewer][token]` snapshots; `/state` returns LOS-filtered `tokens` plus `ghosts` (`ghost:true`, pinned to last-seen x,y). Client renders ghosts as faded dashed circles and keeps them live via `token_leave`.
- **Alternatives:** Broadcast-all-and-hide-in-DOM (rejected: leaks over the wire), true shadow-casting LOS (deferred at the time — now implemented by D44).
- **Consequences:** Out-of-sight tokens are never transmitted (strong leak-prevention); more per-viewer compute per step.
- **Status:** Superseded for geometry by D44; targeted-event/guest mechanics remain accepted.

## D9 — Ghost state is in-memory (`_last_seen`), single-process
- **Context:** Ghosts are derived/ephemeral.
- **Decision:** `_last_seen` lives only in the `ws` process.
- **Consequences:** Ghosts vanish on server restart and would be wrong under multiple uvicorn workers / multi-process. Acceptable for a single-instance self-host; revisit before horizontal scaling.
- **Status:** Accepted (with caveat).

## D10 — Items model in `gear.py` (SSOT for item math)
- **Context:** Armor/magic items requirement; want one place for AC/attunement/charge logic on both REST and WS paths.
- **Decision:** `characters.items` is a JSON column; `gear.clean_items` normalizes/clamps and guarantees ids; `compute_ac`, `attuned_count`, `ATUNE_MAX=3`, `mask_items`. AC rules: **no armor → sheet AC as-is**; light armor adds full DEX mod; medium/heavy do not; `acBonus` counts only when `identified`. Magic items may start **unidentified**; `mask_items` reduces them to "Unidentified item" for viewers who mustn't know them.
- **Status:** Accepted.

## D11 — Per-viewer item masking in `/state`
- **Decision:** DM sees everything; a player sees real items for **their own** character but masked unidentified-magic for everyone else (`mask_items = role!="dm" and member.user_id != viewer`).
- **Consequence:** DM can **Identify** to reveal a magic item's true name/properties table-wide; owner always sees their own kit.
- **Status:** Accepted.

## D12 — Weapon `+N` bonus & ability override; ability on every roll
- **Decision:** Weapons carry `dmgBonus` (magic) added to **both** attack to-hit and damage (crit doubles dice and keeps bonus); `kind:"attack"` accepts an `ability` override (labels the roll `→DEX`); freeform rolls accept optional `ability`(+`prof`) resolved from the roller's sheet.
- **Status:** Accepted.

## D13 — Item actions are WS ops, owner-or-DM gated, DM-only for identify/recharge
- **Decision:** `use_item`, `attune`, `identify`, `recharge` in `app/room/items.py`; results whispered to owner (+DM); attunement capped at 3; depleted (charges 0) items refuse use. Player-initiated `identify`/`recharge` are no-ops.
- **Status:** Accepted.

## D14 — Testing: in-repo `pytest` (primary) + dev-only live WS smoke
- **Decision:** The durable test suite is `pytest` under `tests/`: unit tests
  (`test_path`, `test_mapmodel`, `test_gear`, `test_dice`) plus **integration** tests
  (`test_integration`) that drive the real ASGI app through Starlette's `TestClient`
  over both REST and WebSocket — auth/authz, hidden-info masking (peer private notes +
  unidentified magic), malformed-message resilience, DM-only guards, strict LOS/fog
  token filtering, atomic potion use, and the attunement cap. The hand-rolled raw-WS
  node smoke suites (`vtt_smoke*.mjs`) remain a **dev-only** live-server harness.
- **Consequence:** `pytest` no longer depends on the ephemeral `/tmp/opencode/` scripts
  (TODO-1 resolved). The live suites still need a running server and are **not** part of
  `pytest`; treat them as manual regression aids.
- **Operational hazard:** Do **not** stop the server with `pkill -f` (it has killed the
  tooling shell before); use the saved pidfile (`kill $(cat /tmp/opencode/vtt.pid)`).
- **Status:** Accepted.

## D15 — Kept the legacy 65 green under strict LOS by construction, not by editing assertions
- **Context:** Strict LOS could break old expectations that assumed NPC visibility.
- **Decision/Reality:** The legacy placements happen to sit within radius-6, so they still pass; new LOS assertions in suite 2 deliberately place NPCs far (no `token_add`) vs. in-vision (`token_add`+`step`) vs. leaving (`token_leave`+ghost).
- **Consequence:** Legacy movement tests are vision-adjacent and could turn fragile if the default map/positions change — re-run suite 1 after any grid change.
- **Status:** Accepted (watch item).

## D16 — Backend modularization: `app/room/*` behind a thin `ws.py`
- **Context:** `ws.py` had grown into one ~500-line hub mixing connection plumbing with
  gameplay (dice, movement, LOS, combat, items, traps, dispatch).
- **Decision:** Split gameplay into `app/room/{net,visibility,dispatch,movement,tokens,combat,dice,items,traps}.py`.
  `ws.py` keeps only the WebSocket entry (auth, accept, per-user socket set, connect/disconnect
  lifecycle, receive-loop, generic error handling) and a **re-export shim** so the REST
  call-sites in `rooms.py` (`ws.notify`, `ws.build_seen`, `ws.token_cell`, `ws._last_seen`)
  are unchanged. `dispatch.py` is a flat `type -> handler` registry (no bus/DI).
- **Alternatives:** Big rewrite with an event bus / class-based room objects / repository
  layer (rejected: more indirection than this codebase needs; the flat registry is greppable).
- **Consequences:** Each concern is one small file; message routing is one dict. Re-export
  shim keeps `rooms.py` untouched. Live WS suites (70 + 32) passed unchanged after the split.
- **Status:** Accepted.

## D17 — SQLite: autocommit + explicit `tx()` for multi-statement writes
- **Context:** `sqlite3`'s implicit-transaction mode combined with several statements per
  request (create room, delete char, kick, assign) risked interleaving under concurrency.
- **Decision:** Open connections with `isolation_level=None` (true autocommit), enable WAL
  + `busy_timeout=4000` + foreign keys, and wrap multi-statement writes in `db.tx()`
  (`BEGIN IMMEDIATE … COMMIT/ROLLBACK`). Single-statement writes stay plain `db.x`.
- **Consequences:** No partial writes; writers block briefly (fine at this scale); WAL keeps
  readers concurrent. Still single-file, no ORM.
- **Status:** Accepted.

## D18 — Per-room asyncio map lock + atomic item UPDATE
- **Context:** Map reveal / trap & loot flags / map-edit / walk all do read-modify-write on
  `map_json`; a `use_item` healed HP and decremented charges in two statements.
- **Decision:** A per-room `asyncio.Lock` (`net.map_lock`) serialises every map
  read-modify-write (movement, trap/loot, `map_edit`). `use_item` now applies HP + charge
  decrement in a **single** `UPDATE`.
- **Consequences:** Concurrent walks/edits of the same room can't clobber the map; HP and
  charges are always updated together.
- **Status:** Accepted.

## D19 — Security hardening (auth, cookies, info-leak, logging)
- **Decision:** (1) In-memory sliding-window `ratelimit` on `/login` (10/min) and
  `/register` (10/h), keyed by client IP (optional `X-Forwarded-For` under `VTT_TRUST_PROXY`),
  reset on successful login. (2) Session cookie is `Secure` whenever HTTPS is detected
  (direct scheme, `X-Forwarded-Proto`, or `VTT_COOKIE_SECURE=1`); always `HttpOnly`+`SameSite=Lax`.
  (3) `/state` **strips a peer's private `notes`** for non-DM viewers (loot is appended to
  notes, so this closes a loot/note leak) in addition to `mask_items`. (4) `_last_seen`
  ghosts are **pruned** when a viewer's last socket disconnects (no stale memory, bounded RAM).
  (5) Unexpected REST errors return a generic 500 and are logged; WS handler failures log a
  traceback and send a generic `"Could not process that action"`; non-dict / unparseable WS
  messages are ignored rather than crashing the socket.
- **Consequences:** Removes a real info leak, blunts credential stuffing, keeps dev HTTP
  working, and turns previously-silent handler bugs into logged-but-survivable events.
- **Status:** Accepted.

## D20 — Frontend split into dependency-ordered classic scripts
- **Context:** A single `app/static/app.js` (866 lines) mixed state, API, lobby, WS, canvas
  and wiring; hard to navigate.
- **Decision:** Split **verbatim** into six classic (non-module) `<script>` files under
  `app/static/js/` — `10_core`, `20_lobby`, `30_room`, `40_ws`, `50_canvas`, `60_main` —
  loaded in dependency order from `index.html`. Shared **global scope** is preserved
  deliberately (function/const globals), so no call sites change; cross-file references are
  all call-time.
- **Alternatives:** ES modules (`type=module`) (rejected: would change the whole global-scope
  model and enlarge the regression surface for zero user benefit); a bundler (rejected: adds
  the build step the project deliberately avoids — D1).
- **Consequences:** Navigation wins without touching behaviour. Verified: every top-level
  `function`/`const`/`let` present exactly once (parity-checked vs the original), all files
  pass `node --check`, and the live WS suites still pass.
- **Caveat:** Not validated in a real browser/DOM harness; correctness rests on verbatim
  copy + declaration parity + the WS/REST suites. A future small DOM/Playwright smoke would
  cover canvas wiring specifically.
- **Status:** Accepted.

## D21 — Inline trap/loot editor controls (replaces prompt())
- **Context:** Traps/loot were the only map brushes that collected data via chained
  `prompt()` dialogs. Browsers/iframes that block modal dialogs make `prompt()` return
  `null`, so trap/loot placement silently no-oped while walls/terrain/erase kept working
  (user report: "traps can't be placed").
- **Decision:** When the trap or loot brush is active, the editor toolbar shows inline
  input fields (`#trap-label/#trap-dc/#trap-dmg`, `#loot-label`); `paint()` reads those
  values instead of calling `prompt()`. Same server-side clamps/validation as before.
- **Consequences:** Placement works everywhere, no modal dependency, better UX; drag no
  longer spams prompts. Server `sanitize`/trigger path unchanged (already verified correct).
- **Status:** Accepted.

## D22 — Round-based initiative (roll once, DM ends the round)
- **Context:** Initiative had no round concept; the fighting phase should be organized
  into rounds that the DM ends.
- **Decision:** Initiative order is rolled **once** per combat (`init_start`). `init_next`
  advances `active` (wrapping) without changing the round. A new DM op `init_end_round`
  increments `round` and resets `active` to the leader (0). `room_state.initiative` now
  carries a `round` field; `get_init` back-fills it for pre-existing saves. UI shows
  "— Round N —" and an **End round** button.
- **Alternatives:** Re-rolling initiative every round (rejected — user chose standard 5e
  roll-once, count-rounds).
- **Status:** Accepted.

## D23 — Skills, spellbook + spell slots, and extended item kinds
- **Context:** Add 5e skills, a caster spellbook with slots, and more item kinds (shield,
  wand, ring, tome, …) — all server-authoritative and persisted.
- **Decision:**
  - `characters` gains three JSON columns `skills`, `spells`, `spell_slots`, added via the
    existing safe `migrate()` helper (no destructive change; SQLite only `ALTER ADD`).
  - `gear.py` is the SSOT: `SKILLS` (the 18 5e skills), `clean_skills` (`{key:0|1|2}`,
    1=proficient/2=expertise), `skill_bonus`; `clean_spells`, `clean_slots`;
    `spell_attack`/`spell_save_dc`; extended `KINDS` (shield/wand/staff/scroll/ring/tool/
    wondrous/**spellbook**/…) with shields folded into `compute_ac` (identified only).
  - Roll kinds `skill`, `spell_attack`, `spell_damage`, `spell_dc` added to `handle_roll`;
    new ops `cast` (consumes a leveled slot then rolls its effects, erroring when empty)
    and `long_rest` (DM: restores all slots + `recharge` items).
  - **Magic book = item + panel ("Both"):** the room-sheet Spellbook panel is gated on the
    character carrying a `spellbook` item; the spells/slots themselves live on the
    character. Casting is server-side and always acts on the acting user's own character.
- **Alternatives:** A separate `spells`/`skills` table (rejected — JSON columns match the
  existing `weapons`/`items` pattern and need no joins). Full auto spell-slot-by-level
  tables (rejected — manual `max` is simpler and lets homebrew classes).
- **Consequences:** Client mirrors the bonus math for previews only; the server recomputes
  authoritatively (D3). Migration is non-destructive for existing DBs.
- **Status:** Accepted.

## D24 — NPC / enemy stat blocks live on the token (DM-only)
- **Context:** Monster tokens carried only a label+color; initiative and DEX-save traps used
  DEX=0 for them, they took no trap damage, and DMs had no way to give an enemy ability scores
  or let it cast spells.
- **Decision:**
  - New single JSON column `tokens.npc` (added via `migrate()`, non-destructive) holds the whole
    block: `{name, level, stats{6}, hp, max_hp, ac, speed, spells[], spell_slots{}}`. `app/npc.py`
    is the SSOT: `clean_npc` (bounded), `load`, `dex_mod`/`stat_mod`, and `to_char(block,name)`.
  - **Reuse, don't fork:** `to_char` returns a `{name, stats, level}` pseudo-character so the
    existing `gear.spell_attack`/`spell_save_dc`/`prof_bonus` and the `dice._spell_*_text`
    builders serve NPCs unchanged — one source of truth for all spell math (no second impl).
  - Token-keyed DM actions: `add_token`/`update_npc` (edit the block), `hp` and `roll`/`cast`
    accept a `token_id` for an owner-less, character-less monster token (guarded `if not is_dm`).
    Initiative (`combat.token_dex_mod`) and traps (`traps.hit_trap`) resolve DEX from the token's
    block and apply damage to `npc.hp`. Leveled casts consume per-NPC `spell_slots`.
  - **Hidden from players:** the `npc` block is stripped for non-DM viewers in `rooms.room_state`
    and in the `token_add` path of `visibility.send_token_event`, extending the D11/D19
    hidden-info posture. Rolls themselves post publicly, as at a real table.
- **Alternatives:** DM-owned rows in `characters` (rejected — muddies the library/ownership model
  and the per-user character list). Full PC mirror with weapons/items (deferred — beyond scope).
- **Consequences:** `SELECT * FROM tokens` now carries `npc`; every reader that hands a token to a
  client must keep the strip in sync. Initiative reveals monster DEX mod + totals as before (D22).
- **Status:** Accepted.

## D25 — Fog reveal is gated to player-owned tokens
- **Context:** `movement.walk`/teleport revealed fog on the **shared** `explored` array and
  broadcast `explored` to everyone for *any* token that moved, so marching an NPC lifted fog for
  the whole party (and leaked it on refresh, since the array is persisted).
- **Decision:** Reveal + `set_map` + the `explored` broadcast run only when
  `token.owner_user_id is not None`. NPC/DM-token movement keeps triggering traps/loot but touches
  no fog. Party-shared vision (one player's discovery reveals for the party) is intentionally kept.
  Other reveal sites — `ws` connect (own tokens) and REST `assign` (a player character) — were
  already owner-scoped. The DM needs no reveal (`visible_map` returns the full map for `is_dm`).
- **Alternatives:** Strict per-viewer fog (rejected here — would mean a per-user `explored` array;
  revisit only if the party-shared model is ever dropped).
- **Consequences:** The DM moving a monster can no longer be used to scout the map for players.
- **Status:** Accepted.

## D21 (amendment) — Trap/loot markers render as a colored badge
- The map icon loop computed a marker color but never applied it, so the ⚠/🎁 glyphs drew in the
  leftover dark cell fill-style (effectively invisible where emoji fall back to monochrome, e.g.
  Linux). They are now drawn as a filled circle in the marker color with a white glyph, gated
  role-wise: DM always, players only once `discovered`/`taken_by`.

## D26 — Conditions ride on the token, effects are NOT auto-applied
- **Context:** The table wants a reliable flag for blinded/prone/concentrating/… so the state
  survives refresh and reaches every viewer, without inventing a rules engine.
- **Decision:** `tokens.conds` is a compact JSON list `[{k, rounds}]` normalised by the SSOT
  `app/conditions.py` (`clean_conds`, `add`/`remove`, `step_rounds`, `is_concentrating`). The 15
  canonical 5e conditions ship with a label/glyph/color; any bounded ASCII string is accepted as a
  homebrew condition. **Round progression** runs only at the DM's `init_end_round` (timed entries
  decrement, `rounds==0` are permanent); **long rest clears all**. `cond_add`/`cond_remove` let the
  DM manage any token and players flag **their own**. Conds are carried in `room_state`, the
  `token_add` payload and `_snapshot`, and broadcast live as a `cond` event. Concentrating renders a
  dashed gold ring; other flags as colored dots + sheet chips.
- **Alternatives:** A `character_conditions` table (rejected — conditions are a play-time state, so
  the token is the right owner, matching the `npc`/`death` pattern). Auto-applying mechanical effects
  like every engine (rejected — D3 keeps rules explicit and additive; the flag is the contract,
  effects layer on later).
- **Consequences:** Conditions are **carried, not enforced** by design. Per-round decrement is tied
  to the initiative round counter (D22), so it only advances when the DM ends a round.
- **Status:** Accepted.

## D27 — Death saves are 5e and token-scoped, characters only
- **Context:** A PC dropping to 0 HP needs the 5e dying/stable/dead arc without touching the
  character library (the same character may be dying in one room and fine in the lobby).
- **Decision:** `tokens.death` (`app/room/death.py`) holds `{s, f, stable, dead}`. `handle_hp`
  transitions on damage: fresh state at 0, `+1 fail` per damage while already at 0 (instant death
  when the hit ≥ max HP, re-enter on damage to a *stable* creature), cleared on healing above 0.
  `death_save` (owner or DM) rolls a straight d20: ≥10 success, <10 fail, nat-20 regains 1 HP and
  becomes conscious, nat-1 = two failures; 3 successes → stable, 3 fails → dead. `death_clear` is the DM override.
  **NPCs never enter the state** — they just sit at 0 HP.
- **Alternatives:** Storing `death` on `characters` (rejected — pollutes the library with a transient
  room state). Auto-rolling saves for the player (rejected — the owner rolls their own, DM may proxy).
- **Consequences:** Death state is per-token, so it's hidden/scoped like every other token field; the
  canvas shows a red ring (dying) / ☠ (dead) and a 3×(✓/✗) sheet panel.
- **Status:** Accepted.

## D28 — NPC attacks resolve against a target token's AC, reusing the dice path
- **Context:** A monster needs more than spell slots — reusable natural attacks with a to-hit bonus,
  ideally answering "did it hit and for how much" in one click.
- **Decision:** `npc.attacks` (`clean_attacks`) stores `{id, name, to_hit, dmg, dc, save, reach}`.
  `npc_attack` (DM-only) rolls d20+`to_hit` and, when a `target_id` is given, compares against the
  target's **effective AC** — a character's `gear.compute_ac` or another monster's `ac` — then rolls
  `dmg` on a hit (crit on nat-20, fumble on nat-1). `mode:"damage"`/`mode:"dc"` post just the dice /
  save DC. Everything flows through the existing `do_roll`/`dice_post` (no second dice engine).
- **Alternatives:** Full attack bundles with damage types/conditions and auto-apply (rejected — out of
  scope, and D3 keeps effects manual). Player-facing target picking (rejected — monsters act on the DM's turn).
- **Consequences:** Attack outcomes post publicly (rolls are public at a table, D24); AC is read
  authoritatively server-side, so the DM never sees a wrong AC.
- **Status:** Accepted.

## D29 — Doors are first-class map geometry and block the pathfinder
- **Context:** Closed/locked doors are the one map feature that must actually stop movement, not just
  look the part, and must be authorable and interactable at the table.
- **Decision:** A door sits on an **interior edge** (`dir v` = `x↔x+1`, `dir h` = `y↔y+1`), stored in
  `mp["doors"]` and normalised in `mapmodel.sanitize` (`_canon_door` re-anchors to the lower cell and
  drops out-of-bounds/dup edges). `blocked_edges()` → the pathfinder (`find_path`'s new
  `blocked_edges` param, mirrored in `findPathJS`) refuses to cross a closed edge (and a diagonal may
  not squeeze past one). `mapmodel.find_door` matches either orientation. **Authoring** is the 🚪 map-
  editor brush (edge chosen from the click position); **interaction** is the `door` WS op: DM
  open/close/lock/unlock/remove anything; a player may only **toggle an unlocked door their token is
  adjacent to** (`_player_cell` vs the door's two cells), locking being DM-only. `visible_map` withholds
  doors in unexplored cells.
- **Alternatives:** Doors as terrain cells (rejected — a cell is not an edge; walls already exist).
  Auto path-through when a door is open (rejected — path re-runs on move, so an open door simply
  isn't in `blocked_edges`; no special case needed).
- **Consequences:** `find_path` gained a parameter; every caller must pass `mapmodel.blocked_edges`.
  The JS↔Python pathfinder parity (a known P2 soft spot) must keep the door logic in lockstep.
- **Status:** Accepted.

## D30 — AoE templates are a visual relay, not a resolver
- **Context:** Casting a fireball needs the area shown to the party, but auto-resolving saves/damage
  in an area is a much larger (D3-forbidden) step.
- **Decision:** The DM arms a template (burst/square/line/cone + size + direction), clicks the grid,
  and `app/room/aoe.py` relays the *parameters* to everyone; each client recomputes the covered cells
  from the shared client-side `aoeCells()` and paints a ~7s overlay. Nothing is stored or resolved.
- **Alternatives:** Server computing the cell list (rejected — the geometry is a pure function of the
  params and the client's grid; recomputing avoids trusting a client-supplied array). Auto-resolving
  the area (rejected — D3).
- **Consequences:** DM-only presentation tool; the overlay is transient and cosmetic.
- **Status:** Accepted.

## D31 — Bestiary is a generic, per-user template store keyed on the NPC block
- **Context:** Reusing a well-built monster (or sharing a homebrew archetype) beats rebuilding it per
  room, without importing a copyrighted stat catalog.
- **Decision:** A `creatures(user_id, name, block, tags)` table where `block` is exactly a
  `npc.clean_npc` output — one data model for monsters everywhere (library token, spawned token,
  bestiary entry). REST CRUD (`/api/creatures`, owner-scoped, private) + a sheet "Save to Bestiary"
  capture. **Spawn reuses `add_token`** from the client, so no new spawn authority surface is needed.
- **Alternatives:** A global shared monster library (rejected — ownership/privacy; keep it per-user).
  Seeding a stock catalog (deferred — must be IP-clean; see TODO P3).
- **Consequences:** Any change to `npc.clean_npc` immediately changes the stored-block shape the
  bestiary round-trips — keep them in sync (same mirror concern as D24).
- **Status:** Accepted.

## D32 — Line-of-sight fog was evaluated and gated out (square vision retained)
- **Context:** The vision model was a Chebyshev radius-6 square that ignored walls (D8). True
  shadow-casting LOS was requested as the final roadmap item, hard-gated on the existing
  visibility/fog/hidden-info suites staying green.
- **Decision:** Originally not shipped. A correct LOS must gate **both** the transient light *and* the
  persistent `explored` memory, otherwise terrain already revealed through a
  wall stays visible in `visible_map` and LOS hides nothing that matters. At the time `test_reveal_*`
  and the fog suite pinned `reveal` to the current square contract.
- **Alternatives:** LOS for the live view only (rejected — pointless while memory leaks square);
  rewrite the fog tests to the new model (later accepted as its own Sprint 4 change).
- **Consequences:** The original square-vision gate is obsolete. Walls and closed doors now gate
  both live visibility and exploration under D44; the tests were deliberately rewritten to the
  stricter model.
- **Status:** Superseded by D44.

## D33 — Game-log visibility is a transport property, not a client filter
- **Context:** The game log needs secret GM rolls, self-only rolls and blind rolls without
  leaking their results over the wire.
- **Decision:** `messages.visibility`, `recipient_user_id` and `meta` are canonical fields.
  `app/room/gamelog.py` owns both live delivery and `/state` reconstruction. The four modes
  are `public`, `self`, `blind` and `dm`; blind only sends an acknowledgment to the actor and
  the result to DMs. A non-DM request for `dm` visibility is normalized to `self`.
- **Alternatives:** CSS hiding (rejected: full data leak), separate per-recipient message
  copies (rejected: redundant and hard to reconstruct), client filtering (rejected: violates D3).
- **Consequences:** Message queries return role-filtered rows. Dice results and roll metadata
  are deliberately carried together, allowing the UI to retain ADV/DIS and cover context.
- **Status:** Accepted.

## D34 — HP, death and defenses use one server-side health reducer
- **Context:** Damage could enter from manual HP edits, traps, potions and NPC attacks, while
  temp HP, typed damage and death saves were beginning to duplicate transition logic.
- **Decision:** `app/room/health.py::change_hp` is the single transition path for PCs and NPC
  blocks. Damage type is an explicit optional field. Defensive reduction runs before temp HP
  or real HP is consumed; death save nat-20 restores 1 HP and clears dying. Massive damage
  uses post-defense damage and only fires when damage actually occurs.
- **Alternatives:** Patching each call site separately (rejected: divergence), encoding
  vulnerability in dice rolls (rejected: defensive properties belong to the target).
- **Consequences:** Manual HP remains supported, while typed interactions receive a clear
  extension point without adding a full effect engine.
- **Status:** Accepted.

## D35 — Rests separate narrative recovery from condition removal
- **Context:** D&D 5e long rest restores class/spell resources and does not automatically
  erase arbitrary conditions. A blanket clear was a table surprise.
- **Decision:** Short rest is owner-or-DM and is hit-dice based. Long rest is DM-triggered;
  HP, slots, hit dice and resource state reset, while `conditions` remain untouched unless the
  message supplies explicit `clear_conditions: true`.
- **Alternatives:** Auto-clear all conditions (rejected), automatic party-wide short rest
  (rejected: the party may not actually be resting).
- **Consequences:** Existing long-rest behavior remains opt-in, and the table retains control
  over magical/condition effects without inventing auto-resolution.
- **Status:** Accepted.

## D36 — Encounter and journal data are server-scoped by ownership and room
- **Context:** Saved encounters and handouts are DM materials that should never leak through
  the shared room state.
- **Decision:** `encounters` are owner-scoped global templates. `notes` are room-scoped and
  carry `dm`, `party` or `selected` visibility plus an explicit recipient ID list. The note
  endpoint parses recipients server-side instead of using textual SQL matching.
- **Alternatives:** Storing JSON in `room_state` (rejected: unbounded state blob), client
  filtering (rejected: violates D3), JSON `LIKE` recipient lookup (rejected: false positives).
- **Consequences:** Encounter spawn can reuse saved creature blocks and private note reads are
  safe against malformed `recipients` values.
- **Status:** Accepted.

## D37 — Map pins, pings and ruler have different trust levels
- **Context:** Map annotations and communication tools have different state, visibility and
  abuse characteristics.
- **Decision:** Pins are sanitized persistent map data with `dm`/`players`/`revealed`
  visibility. Pings are rate-limited live broadcasts and are deliberately not persisted.
  The ruler is purely client-side measurement. Server-side visibility and fog filtering own
  the security boundary for pins.
- **Alternatives:** Make all ephemeral (rejected: DM planning notes should survive refresh),
  make all persistent (rejected: pings have no audit value and can spam state), validate ruler
  server-side (rejected: it is display-only and cannot mutate state).
- **Consequences:** UI tools can be lightweight without weakening the map information model.
- **Status:** Accepted.

## D38 — Chat history is separated from game-log delivery at the database boundary
- **Context:** The `messages` table had become both a game log and chat store. Client-side
  filtering could separate presentation but could not prevent private data from being sent.
- **Decision:** Chat and narrative rows are delivered by `app/room/chat.py`; dice/system rows
  remain in `app/room/gamelog.py`. Message metadata carries `channel`, `visibility` and a
  JSON `recipient_ids` list. `/state` queries chat and game log separately and applies the
  viewer's authorization in SQL.
- **Alternatives:** Use only `meta` (rejected: unqueryable), add `display:none` (rejected: leaks
  data), create a separate `chat` table (deferred: existing message history and replay code are
  already built around `messages`).
- **Consequences:** Replay and live delivery share explicit visibility concepts, and private
  chat can be tested without changing dice visibility.
- **Status:** Accepted.

## D39 — Player whispers are not secretly visible to the DM
- **Context:** Some VTTs make every player whisper DM-visible; others protect player-to-player
  private communication.
- **Decision:** A whisper is visible only to its sender and explicit recipients. Player-to-DM
  messages naturally include the DM. A DM's untargeted `dm` channel message is visible only to
  DMs. This choice is deliberately documented in the README.
- **Alternatives:** Make the DM an omniscient listener (rejected for this product: it removes a
  trust boundary players expect), make all chat visible to everyone (rejected: no whisper).
- **Consequences:** DM private notes and player whispers need separate handling. The rule must be
  preserved by any future moderation/audit feature if added.
- **Status:** Accepted.

## D40 — DM personas and NPC speech are authorized server-side
- **Context:** Narrative immersion requires speaking as NPCs/personas, but the chat sender is a
  security and identity boundary.
- **Decision:** Only DM sockets may set `sender_kind` to `persona` or `npc`. The database always
  records the real `user_id`. Persona names matching any room member username are rejected. NPC
  speech requires a target token that belongs to the room, has no owner/character attachment and
  has a parseable NPC block.
- **Alternatives:** Let players impersonate anyone (rejected: identity spoofing), hide provenance
  in `meta` only (rejected: unqueryable), validate only on the client (rejected: D3).
- **Consequences:** NPCs can be renamed/deleted while old messages retain their display persona;
  this is preferable to changing chat history or enforcing cascading edits.
- **Status:** Accepted.

## D41 — Audio is a safe-URL projection, not an embedded content pipeline
- **Context:** Direct audio, YouTube and Spotify can all improve table atmosphere, but arbitrary
  URLs, embed HTML and media downloading introduce different security and legal risks.
- **Decision:** Direct HTTP(S) audio and same-origin `/uploads` paths are allowed. YouTube and
  Spotify URLs are parsed and their media IDs revalidated; fixed `youtube-nocookie` or
  Spotify embeds are constructed by the server. No caller-supplied iframe/HTML is rendered and
  no media is scraped or downloaded. Selective effects are limited to direct audio URLs and
  receive server-resolved recipients.
- **Alternatives:** Accept arbitrary iframe embeds (rejected: XSS/CSP), download media (rejected:
  out of scope and rights risk), allow players to control room ambience (rejected: atmosphere
  control is DM responsibility).
- **Consequences:** Player volume/mute are local UX, not authoritative room state. Third-party
  browsers may still block autoplay, so direct effects are the more reliable selective channel.
- **Status:** Accepted.

## D42 — `AGENT_GUIDE.md` is a map, not an authoritative specification
- **Context:** Future agents need a fast architecture map but generated documentation tends to
  drift and can confidently mislead.
- **Decision:** Add `AGENT_GUIDE.md` as a deliberately concise repository/feature/file/message/
  hazard map with an explicit code-wins rule.
- **Alternatives:** No guide (rejected: repeated discovery cost), generate every fact with line
  numbers (rejected: brittle and noisy), treat it as an ADR/source of truth (rejected).
- **Consequences:** Changes to architectural boundaries should update the guide, but implementation
  inspection remains mandatory before edits.
- **Status:** Accepted.

## D43 — Token footprint is an `n×n` square anchored at `x/y`
- **Context:** Large monsters were visually scaled but still occupied only one pathfinding cell, so
  a Huge creature could stand on the map edge or squeeze through a one-cell corridor.
- **Decision:** `app/footprint.py` is the footprint SSOT: Tiny/Small/Medium 1×1, Large 2×2, Huge 3×3,
  Gargantuan 4×4. The existing token `x/y` remains the top-left occupied cell center; footprint
  extends right/down. A clicked movement destination is the anchor. Spawns and size changes find the
  nearest valid origin; confirmed moves require a valid final footprint.
- **Alternatives:** Center-based storage (rejected: it would reinterpret every legacy token),
  circular templates (rejected: the existing grid and rules use squares), per-client geometry (rejected).
- **Consequences:** Server pathfinding can enforce Large+ terrain rules, collision and spawning with
  one representation. Same-owner pass-through is intentionally retained; collision blocks different
  distinct owners only at final placement.
- **Status:** Accepted.

## D44 — Deterministic conservative LOS replaces square vision
- **Context:** Sprint 4 requires walls and closed doors to hide terrain/tokens, including exploration
  memory, not merely the current view.
- **Decision:** `app/los.py` casts deterministic integer DDA rays from footprint source cells. Walls
  and closed-door edges block. A ray through an exact grid corner is allowed only when both relevant
  orthogonal transitions are open, preventing vision through sealed diagonal corners. The existing
  radius 6 remains; footprint sources/targets need only one occupied cell to be visible. Live LOS and
  persistent exploration use the same result.
- **Alternatives:** Recursive shadowcasting (rejected for now: larger rewrite and floating-point drift),
  live-view-only LOS (rejected: old memory leaks), optimistic Bresenham (rejected: corner ambiguity).
- **Consequences:** DM hiding or re-fogging can no longer be undone merely by moving a player token.
  Visibility and fog are server-authoritative; hidden token payloads remain absent before transmission.
- **Status:** Accepted. Supersedes the square-vision portions of D8 and the deferral in D32.

## D45 — Manual fog edits room-wide exploration, not live sight
- **Context:** DMs need explicit reveal/hide tools while a player's current line of sight remains
  mechanically correct.
- **Decision:** DM-only `fog_edit` updates `map.explored` for up to 512 cells. Revealed/hid state is
  broadcast to all players. `visible_map` returns terrain when persistent exploration **or** current
  LOS visibility is true, so hiding an old memory cell does not corrupt a live view.
- **Alternatives:** Per-player fog (rejected: current schema has one shared `explored` bitmap),
  erase current visibility too (rejected: would blind a player standing in plain sight).
- **Consequences:** Manual reveal is simple and shared across all players; private per-player fog needs
  a schema change later. Map-editor reset-fog checkbox now has an actual server effect.
- **Status:** Accepted.

## D46 — Movement state and path previews are server-owned
- **Context:** The client previously mirrored A*, while walk tasks and traps were server-controlled;
  large footprints/LOS made duplicated route planning unsafe.
- **Decision:** Players preview their own token via `path_preview`; the server validates ownership,
  footprint, walls/doors, collision and current explored/visible cells. Walk tasks emit `move_state`;
  trap trigger and DM `stop_move` cancel the task and announce a stopped walk. Movement confirmation
  recomputes the authoritative path independently of the preview.
- **Alternatives:** Keep client A* as source of truth (rejected), block friendly pass-through at every
  animation step (rejected: conflicts with chosen pass-through policy), add a resumable move queue
  (deferred).
- **Consequences:** Hidden terrain cannot be inferred through preview, path/UI remain synchronized,
  and traps now interrupt an in-flight walk. Intermediate movement may still overlap same-owner tokens;
  only final placements are collision-authoritative.
- **Status:** Accepted.

## D47 — One authoritative world, multiple client-local renderers
- **Context:** We want a Tactical view and a Diorama view of the same room without duplicating game
  state or forcing every player into one presentation. A naive "view mode" flag on the server would
  turn a personal preference into shared, room-level state.
- **Decision:** The server keeps one authoritative, already per-viewer-filtered world
  (`state.grid`/`state.tokens`/`state.ghosts`). Each browser picks its own renderer via a
  **client-local** `state.viewMode` ("tactical" | "diorama", invalid → tactical) persisted in
  localStorage (`dndtable-view-mode`). `draw()` is the single dispatch point to `drawTactical()` or
  `drawDiorama()`; every existing call site keeps calling `draw()` and follows the active view. The
  DM map editor always renders tactical. View mode is **never** sent over WebSocket, persisted
  server-side, or allowed to influence permissions, movement, LOS, fog or combat.
- **Alternatives:** Room-level view setting (rejected: not personal), separate map/state per view
  (rejected: duplication and divergence), a full OO renderer framework (rejected: the frontend is
  function-based; a thin dispatcher is enough).
- **Consequences:** Two clients in the same room can show different views independently. Rendering
  mode can never change gameplay, and the existing per-viewer visibility boundary is reused
  unchanged, so a second renderer cannot leak hidden information.
- **Status:** Accepted.

## D48 — Diorama is a projection prototype over reused state, not a new engine
- **Context:** We need to prove "one world → two renderers" cheaply, with no sprite assets, no WebGL,
  and no risk to the freshly hardened Tactical renderer.
- **Decision:** `app/static/js/55_diorama.js` projects the shared grid through a deterministic 2:1
  isometric map (`dioProj`/`dioUnproj`) onto the same Canvas: floors as diamonds, walls as extruded
  boxes, doors as upright open/closed/locked panels, tokens/ghosts as upright "paper" billboards.
  Painter sort is split into a tile pass then a billboard pass (tokens always on top, as in Tactical).
  Visibility is read through the existing `visibleHere()` mask — no second visibility authority.
  Interaction reuses authoritative handlers only (door toggle, `path_preview`, `move`); there is no
  client-side A*. **No speculative schema:** visual metadata (materials, elevation, sprite/scale/
  rotation/layer, per-object blocks-movement/vision) is *deferred*; it is expected to live inside the
  existing `room_state.map_json` document via the map sanitizer, not as new DB columns.
- **Alternatives:** Three.js/WebGL (rejected: complexity/risk), a bespoke 3D camera (rejected), new
  DB columns for visual metadata now (rejected: speculative).
- **Consequences:** Diorama is a functional placeholder view. Deferred/limited: no sprite art, no
  dynamic lighting/shadows, no elevation gameplay, no rotation/zoom camera, coarse billboard picking,
  and Diorama movement is a server-preview only (precise manual movement stays a Tactical action).
  Future visual metadata should extend `mapmodel.sanitize()` rather than the schema.
- **Status:** Accepted.

## D49 — Core/transport coupling audit; keep handlers thin, extract nothing speculative
- **Context:** Sprint 5B audited whether gameplay rules are welded to FastAPI/WebSocket
  transport, to keep a future DM-automation or local/single-player adapter possible. Goal
  was a boring, test-safe separation — not a rewrite.
- **Decision:** The transport layer is already thin: `ws.py` keeps only connection plumbing
  and every `app/room/*` handler parses+authorizes, then calls pure gameplay helpers
  (`path.find_path`, `footprint.*`, `los.*`, `mapmodel.*`, `health.*`, `gear.*`, `npc.*`).
  No CQRS/event-sourcing/DI/bus/plugin layer was introduced. The only cross-handler duplication
  worth naming is the "reveal a player token's LOS cells" expression, used by `ws.py` and
  `movement.py`; it is a two-line call into pure functions with **different** `owner=None`
  semantics and one copy sits on the movement hot path, so it was deliberately **not** extracted
  (marginal gain, real regression risk). Gameplay operations should continue to read like
  commands (move/door/damage/heal/reveal) reachable without a socket; new automation must call
  those helpers, never a WebSocket handler.
- **Alternatives:** A `visibility.token_reveal_cells()` dedup (rejected as not clearly
  beneficial); an application/command layer (rejected: speculative, violates D16's thin-shim
  intent and would churn hot paths for no behavioral gain).
- **Consequences:** The rules core stays callable headlessly; the audit added cross-system
  regression tests (`tests/test_hardening.py`) instead of moving code. A known design gap was
  recorded rather than fixed: `walk()` computes its path once, so a door closed *mid-walk* does
  not reroute the in-flight token (see TODO).
- **Status:** Accepted.

## D50 — Per-step authoritative movement revalidation (`path_blocked` stop)
- **Context:** A walk computed its A* route once and replayed it blindly (D46). If a door
  closed or a wall appeared mid-walk, the token could phase through the new obstacle — the
  route was only authoritative when the walk began (recorded gap in D49 / TODO).
- **Decision:** `walk()` revalidates **every step immediately before applying it** against the
  current map: bounds, walls, footprint cells and `blocked_edges` (closed/locked doors) via
  `path.step_legal()`. That function was extracted from `find_path`'s own validity closures,
  so pathfinding and revalidation share one legality source (footprint-aware, including the
  conservative diagonal mid-cell rule — Sprint 4 rules unchanged). An illegal step is never
  written: the walk ends with `move_state {moving:false, reason:"path_blocked"}`, the mover's
  socket additionally gets a private `error`, and the token stays on its last broadcast cell.
  Validation and the position write run inside the existing per-room `map_lock` — the same
  lock `handle_door`/`handle_map_edit` hold — so on the single event loop no world mutation
  can interleave between "check" and "apply". One lifecycle, four endings: completed,
  manual (DM stop), trap, path_blocked; all clean up `_walks` via the existing `finally`.
- **Alternatives:** Re-running A* each step (rejected: expensive and re-plans routes the
  player never chose); cancelling silently (rejected: mover gets at least a private reason);
  a lock-free "validate then write" (rejected: the door close could slip between the two).
- **Consequences:** Stale routes can no longer violate geometry; mid-walk token resizes also
  stop safely (current side is used). Residual limitation: single-loop atomicity — a
  multi-worker deployment would need shared state before this guarantee means anything
  (already voided for ghosts/fog by the cross-cutting assumptions). Pixel math now reads the
  live `mp["cell"]` per step instead of a value captured at walk start.
- **Status:** Accepted. Tests: door-closed-mid-walk and wall-painted-mid-walk
  (`tests/test_hardening.py`); trap-stop and DM-stop suites unchanged.

## D51 — Quest Log: structured persistent progress; journal stays free-form
- **Context:** DMs need objectives with authoritative state ("Speak with the
  guard ✓"), not only prose journal notes. Journal notes were never queryable
  and mixing the two would make "what is still open?" a text-parsing problem.
- **Decision:** New `quests` table: `title, description, status
  (active|completed|failed|hidden), objectives JSON [{id,text,done,hidden}],
  visibility (party|dm), created/updated`. Pure game operations in
  `app/quests.py` (create/update/add_objective/set_objective/complete/fail/
  delete + `visible_for`); WS handlers in `app/room/quests.py` are thin
  (parse → DM-authorize → op → notice → payload-less `quests_changed`
  broadcast; clients refetch `/state`). **Server-side filtering in
  `visible_for` is the security boundary**: DM-only quests, `hidden` status
  and objective-level `hidden` hints are never serialized into any player
  payload, live or `/state`; reconnecting clients rebuild quests from
  `/state` only. `room_state()` gained `"quests"`.
- **Alternatives:** Journal notes with a quest category (rejected: no
  structure/derivation); REST CRUD like notes (rejected: mutations need live
  room broadcast; REST kept read-free); per-player visibility (deferred — fits
  `recipients` later, not built today).
- **Consequences:** Triggers can later call `complete_quest(...)` exactly like
  a DM click. Quest edits are last-write-wins (no lock) — acceptable for
  low-frequency DM authoring; revisit if automation starts editing quests.
- **Status:** Accepted. Tests: `tests/test_quests.py`.

## D52 — Notices are transient presentation; game events are facts, not state
- **Context:** Quest changes must be visible in the moment, and future
  automation needs a seam to observe the game — without either becoming a
  second source of truth.
- **Decision:** **Notices** (`QUEST ADDED …`) go through the existing
  game-log (`gamelog.post_message`, `kind="system"`) with visibility bound to
  the quest's visibility (DM-only quests produce DM-only notices). They are
  chronicle/presentation only: reconnect reconstructs quests from `/state`,
  never by replaying notices. **Game events** (`app/events.py`) are small
  plain dicts `{type, room_id, actor_id, target_id, data}` emitted **after**
  an operation has committed its state change — an event is never where state
  lives. One bounded in-process ring for diagnostics; synchronous listener
  registry; a raising listener can never break the emitting operation.
  Deliberately NOT an event bus: no queue, no persistence, no DI container.
- **Future trigger direction (documented, NOT built):**
  `GameEvent → trigger condition → game operation`, e.g.
  `enter_area("crypt") → CompleteObjective(quest, objective)` or
  `open_door("ancient_gate") → StartEncounter(...)`. Triggers must call the
  same pure operations humans use (D49) — never fake WebSocket clients.
- **Wired today (facts only, 4 families):** `door_opened/door_closed/
  door_removed`, `trap_triggered`, `quest_started/updated/completed/failed`.
  More events are added when an operation needs observers, not speculatively.
- **Consequences:** Dropping every event loses nothing authoritative (tests
  prove state and events co-exist, not that state depends on events).
- **Status:** Accepted. Tests: quest-event + door-event emission + plain-JSON
  transport-freeness in `tests/test_quests.py`.

## D53 — Character classes are a collection; total level is derived
- **Context:** A single `char_class`/`level` pair makes multiclassing a schema
  migration later. Modeling it wrong now is the expensive mistake.
- **Decision:** Progression is a collection:
  `class_levels = [{"class_id":"fighter","level":3},{"class_id":"wizard","level":2}]`
  (JSON column, additive migration). `app/progression.py` provides the strict
  validator (ids lowercase ≤24 chars, levels 1–20, no duplicates, total ≤20 —
  invalid input is **rejected whole**, never half-applied), the single
  canonical `total_character_level()` (sum of entries, legacy `level` column
  as single-class fallback) and the `set_class_levels()` operation which also
  keeps the legacy `level` column in sync so every existing consumer (hit
  dice, slots, sheet math) sees the derived total. `gear.prof_bonus()` now
  derives from `total_character_level` — no re-summed copies. WS
  `class_levels`: owners manage their own characters, the DM may advance
  characters **of this room's members**; anyone else is refused server-side.
  Engine structure only — no class feature tables, subclass text or
  progression prose (licensing boundary, ATTRIBUTION.md); per-class hit dice/
  resources/spellcasting attach to these entries later (TODO), no speculative
  columns today. UI is a read-only sheet line `Warrior 3 / Adept 2 Lv4`.
- **Alternatives:** `class = "fighter/wizard 3/2"` string (rejected: parsed
  forever); one row per class in a table (rejected: overkill for one JSON
  list at this scale).
- **Status:** Accepted. Tests: `tests/test_progression.py`.

## D54 — Ability geometry is generic and independent of named spells
- **Context:** AoE templates existed only as a client-side visual relay
  (`aoeCells` in `10_core.js`). Future abilities need the same geometry
  resolved server-side, and it must not become hard-wired to spell names.
- **Decision:** `app/effects.py::effect_cells(shape, size, x, y, w, h,
  direction)` — pure, deterministic, boundary-clipped — covering
  `point|line|cone|circle|square` (circle/square double as sphere/cube map
  projections). An effect is `shape + size + origin + direction`; future
  fields (range, save, damage expression/type, condition, duration,
  concentration) attach as data HERE — never as spell names. NO spell
  catalogue is introduced; tests use original names ("Training Cone" style
  parameters, not content). The exact-45° cone edge is a float tie: the
  server matches the shipped client's exclude-behavior, and the parity test
  (`tests/test_effects.py`, Node `vm`) locks server preview ≡ client cells
  cell-for-cell. The DM relay (`app/room/aoe.py`, D30) stays presentation-
  only; resolution remains a deliberate future step.
- **Status:** Accepted.

## Cross-cutting assumptions (read before scaling)
- Single uvicorn process, single event loop; `LOOP` captured in `main.py` for thread-safe broadcasts.
- `VTT_DATA_DIR` isolates the SQLite/`secret.key`/uploads tree.
- Public deploy expects a TLS reverse proxy in front (see README Notes).
